# Tai Lieu Yeu Cau Phan Mem (SRS)
## he-thong-quan-ly-thu-vien

## 1. Tong Quan Du An
Hệ thống quản lý thư viện giúp thủ thư quản lý sách, độc giả và theo dõi lịch sử mượn trả. Nó tự động tính phí phạt cho các sách trả quá hạn, đồng thời cung cấp chức năng tìm kiếm sách tiện lợi theo tên và tác giả cho độc giả.

## 2. User Stories
### US001 - Quản lý thêm sách mới

**Story:** Là thủ thư, tôi muốn thêm sách mới vào hệ thống để cập nhật danh mục sách hiện có.

**Acceptance Criteria:**
  - Hệ thống cho phép nhập thông tin đầy đủ của sách (tên, tác giả, ISBN, số lượng, v.v.).
  - Sách mới được thêm thành công và hiển thị trong danh sách sách của thư viện.

### US002 - Quản lý thông tin độc giả

**Story:** Là thủ thư, tôi muốn thêm và quản lý thông tin độc giả để cấp quyền mượn sách và theo dõi hoạt động của họ.

**Acceptance Criteria:**
  - Thủ thư có thể nhập thông tin chi tiết của độc giả (tên, mã độc giả, ngày sinh, địa chỉ, v.v.).
  - Thông tin độc giả được lưu trữ và có thể tìm kiếm, chỉnh sửa hoặc xóa.

### US003 - Ghi nhận mượn sách

**Story:** Là thủ thư, tôi muốn ghi nhận việc độc giả mượn sách để cập nhật trạng thái sách và theo dõi thời gian mượn.

**Acceptance Criteria:**
  - Hệ thống cho phép chọn sách và độc giả để tạo một bản ghi mượn sách mới.
  - Trạng thái của sách được cập nhật thành 'đang mượn' và lưu lại ngày mượn, ngày trả dự kiến.

### US004 - Ghi nhận trả sách và tính phí phạt

**Story:** Là thủ thư, tôi muốn ghi nhận việc độc giả trả sách và tự động tính phí phạt nếu quá hạn để đảm bảo tuân thủ quy định.

**Acceptance Criteria:**
  - Thủ thư có thể chọn bản ghi mượn sách và đánh dấu là 'đã trả'.
  - Nếu sách được trả sau ngày đáo hạn, hệ thống tự động tính toán và hiển thị số tiền phí phạt.

### US005 - Tìm kiếm sách

**Story:** Là độc giả, tôi muốn tìm kiếm sách theo tên hoặc tác giả để dễ dàng tìm thấy cuốn sách mình muốn đọc.

**Acceptance Criteria:**
  - Hệ thống cung cấp một thanh tìm kiếm cho phép nhập từ khóa tên sách hoặc tác giả.
  - Kết quả tìm kiếm hiển thị danh sách các cuốn sách phù hợp với từ khóa đã nhập.

### US006 - Xem lịch sử mượn trả của độc giả

**Story:** Là thủ thư, tôi muốn xem lịch sử mượn trả của từng độc giả để kiểm tra hoạt động và các khoản nợ phí phạt.

**Acceptance Criteria:**
  - Thủ thư có thể chọn một độc giả và xem danh sách tất cả các cuốn sách họ đã mượn và trả.
  - Lịch sử hiển thị chi tiết về ngày mượn, ngày trả, và bất kỳ khoản phí phạt nào liên quan đến từng lần mượn.

### US007 - Cập nhật và xóa sách

**Story:** Là thủ thư, tôi muốn cập nhật thông tin hoặc xóa sách khỏi hệ thống để quản lý danh mục sách một cách linh hoạt.

**Acceptance Criteria:**
  - Thủ thư có thể chọn một cuốn sách hiện có và chỉnh sửa các thông tin chi tiết của nó.
  - Thủ thư có thể xóa một cuốn sách khỏi hệ thống, miễn là nó không đang trong trạng thái được mượn.