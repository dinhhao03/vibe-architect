const app = require('./app');
const { pool } = require('./db');

const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
        console.log('HTTP server closed.');
        pool.end().then(() => {
            console.log('PostgreSQL pool has ended.');
            process.exit(0);
        }).catch(err => {
            console.error('Error closing PostgreSQL pool', err);
            process.exit(1);
        });
    });
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);