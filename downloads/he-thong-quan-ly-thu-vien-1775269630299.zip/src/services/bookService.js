const { query } = require('../db');

class BookService {
    static validateBookData(data, isUpdate = false) {
        if (!isUpdate && (!data.title || !data.author || !data.isbn || !data.publication_year || !data.total_copies)) {
            throw Object.assign(new Error('Title, author, ISBN, publication year, and total copies are required'), { status: 400 });
        }
        if (data.title && typeof data.title !== 'string' || data.title.length < 1) {
            throw Object.assign(new Error('Title must be a non-empty string'), { status: 400 });
        }
        if (data.author && typeof data.author !== 'string' || data.author.length < 1) {
            throw Object.assign(new Error('Author must be a non-empty string'), { status: 400 });
        }
        if (data.isbn && !/^(\d{10}|\d{13})$/.test(String(data.isbn))) {
            throw Object.assign(new Error('ISBN must be a 10 or 13 digit string'), { status: 400 });
        }
        if (data.publication_year && (!Number.isInteger(data.publication_year) || data.publication_year < 1000 || data.publication_year > new Date().getFullYear())) {
            throw Object.assign(new Error(`Publication year must be a valid year between 1000 and ${new Date().getFullYear()}`), { status: 400 });
        }
        if (data.total_copies && (!Number.isInteger(data.total_copies) || data.total_copies <= 0)) {
            throw Object.assign(new Error('Total copies must be a positive integer'), { status: 400 });
        }
        if (data.available_copies !== undefined && (!Number.isInteger(data.available_copies) || data.available_copies < 0)) {
            throw Object.assign(new Error('Available copies must be a non-negative integer'), { status: 400 });
        }
        if (data.available_copies !== undefined && data.total_copies !== undefined && data.available_copies > data.total_copies) {
            throw Object.assign(new Error('Available copies cannot exceed total copies'), { status: 400 });
        }
    }

    static async findAllBooks(title, author) {
        let queryText = 'SELECT * FROM books';
        const queryParams = [];
        const conditions = [];
        let paramIndex = 1;

        if (title) {
            conditions.push(`title ILIKE $${paramIndex++}`);
            queryParams.push(`%${title}%`);
        }
        if (author) {
            conditions.push(`author ILIKE $${paramIndex++}`);
            queryParams.push(`%${author}%`);
        }

        if (conditions.length > 0) {
            queryText += ' WHERE ' + conditions.join(' AND ');
        }
        queryText += ' ORDER BY title';

        const result = await query(queryText, queryParams);
        return result.rows;
    }

    static async findBookById(id) {
        const result = await query('SELECT * FROM books WHERE id = $1', [id]);
        return result.rows[0];
    }

    static async createBook(bookData) {
        BookService.validateBookData(bookData);

        const { title, author, isbn, publication_year, genre, total_copies } = bookData;
        const available_copies = total_copies; // Initially all copies are available

        try {
            const result = await query(
                'INSERT INTO books (title, author, isbn, publication_year, genre, total_copies, available_copies) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
                [title, author, isbn, publication_year, genre, total_copies, available_copies]
            );
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505' && error.constraint === 'books_isbn_key') {
                throw Object.assign(new Error('ISBN already exists'), { status: 400 });
            }
            throw error;
        }
    }

    static async updateBook(id, bookData) {
        BookService.validateBookData(bookData, true);

        const fields = [];
        const values = [];
        let paramIndex = 1;

        if (bookData.title !== undefined) {
            fields.push(`title = $${paramIndex++}`);
            values.push(bookData.title);
        }
        if (bookData.author !== undefined) {
            fields.push(`author = $${paramIndex++}`);
            values.push(bookData.author);
        }
        if (bookData.isbn !== undefined) {
            fields.push(`isbn = $${paramIndex++}`);
            values.push(bookData.isbn);
        }
        if (bookData.publication_year !== undefined) {
            fields.push(`publication_year = $${paramIndex++}`);
            values.push(bookData.publication_year);
        }
        if (bookData.genre !== undefined) {
            fields.push(`genre = $${paramIndex++}`);
            values.push(bookData.genre);
        }
        if (bookData.total_copies !== undefined) {
            fields.push(`total_copies = $${paramIndex++}`);
            values.push(bookData.total_copies);
        }
        if (bookData.available_copies !== undefined) {
            fields.push(`available_copies = $${paramIndex++}`);
            values.push(bookData.available_copies);
        }

        if (fields.length === 0) {
            return BookService.findBookById(id); // No fields to update, return current book
        }

        values.push(id);
        try {
            const result = await query(
                `UPDATE books SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${paramIndex} RETURNING *`,
                values
            );
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505' && error.constraint === 'books_isbn_key') {
                throw Object.assign(new Error('ISBN already exists'), { status: 400 });
            }
            throw error;
        }
    }

    static async deleteBook(id) {
        // A book can only be deleted if all copies are available (i.e., total_copies == available_copies)
        const book = await BookService.findBookById(id);
        if (!book) {
            return false; // Book not found
        }
        if (book.available_copies < book.total_copies) {
            throw Object.assign(new Error('Cannot delete book with borrowed copies'), { status: 400 });
        }

        const result = await query('DELETE FROM books WHERE id = $1 RETURNING id', [id]);
        return result.rowCount > 0;
    }
}

module.exports = BookService;