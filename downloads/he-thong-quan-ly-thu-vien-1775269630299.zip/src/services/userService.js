const { query } = require('../db');

class UserService {
    static validateUserData(data, isUpdate = false) {
        if (!isUpdate && (!data.username || !data.password_hash)) {
            throw Object.assign(new Error('Username and password_hash are required'), { status: 400 });
        }
        if (data.username && typeof data.username !== 'string' || data.username.length < 3) {
            throw Object.assign(new Error('Username must be a string of at least 3 characters'), { status: 400 });
        }
        if (data.password_hash && typeof data.password_hash !== 'string' || data.password_hash.length < 6) {
            throw Object.assign(new Error('Password hash must be a string of at least 6 characters'), { status: 400 });
        }
        if (data.role && !['librarian', 'admin'].includes(data.role)) {
            throw Object.assign(new Error('Role must be either "librarian" or "admin"'), { status: 400 });
        }
    }

    static async findAllUsers() {
        const result = await query('SELECT id, username, role, created_at, updated_at FROM users');
        return result.rows;
    }

    static async findUserById(id) {
        const result = await query('SELECT id, username, role, created_at, updated_at FROM users WHERE id = $1', [id]);
        return result.rows[0];
    }

    static async createUser(userData) {
        UserService.validateUserData(userData);

        const { username, password_hash, role = 'librarian' } = userData;

        try {
            const result = await query(
                'INSERT INTO users (username, password_hash, role) VALUES ($1, $2, $3) RETURNING id, username, role, created_at, updated_at',
                [username, password_hash, role]
            );
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505' && error.constraint === 'users_username_key') {
                throw Object.assign(new Error('Username already exists'), { status: 400 });
            }
            throw error;
        }
    }

    static async updateUser(id, userData) {
        UserService.validateUserData(userData, true);

        const fields = [];
        const values = [];
        let paramIndex = 1;

        if (userData.username !== undefined) {
            fields.push(`username = $${paramIndex++}`);
            values.push(userData.username);
        }
        if (userData.password_hash !== undefined) {
            fields.push(`password_hash = $${paramIndex++}`);
            values.push(userData.password_hash);
        }
        if (userData.role !== undefined) {
            fields.push(`role = $${paramIndex++}`);
            values.push(userData.role);
        }

        if (fields.length === 0) {
            return UserService.findUserById(id); // No fields to update, return current user
        }

        values.push(id);
        const result = await query(
            `UPDATE users SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${paramIndex} RETURNING id, username, role, created_at, updated_at`,
            values
        );
        return result.rows[0];
    }

    static async deleteUser(id) {
        const result = await query('DELETE FROM users WHERE id = $1 RETURNING id', [id]);
        return result.rowCount > 0;
    }
}

module.exports = UserService;