const { query } = require('../db');

class MemberService {
    static validateMemberData(data, isUpdate = false) {
        if (!isUpdate && (!data.first_name || !data.last_name)) {
            throw Object.assign(new Error('First name and last name are required'), { status: 400 });
        }
        if (data.first_name && typeof data.first_name !== 'string' || data.first_name.length < 1) {
            throw Object.assign(new Error('First name must be a non-empty string'), { status: 400 });
        }
        if (data.last_name && typeof data.last_name !== 'string' || data.last_name.length < 1) {
            throw Object.assign(new Error('Last name must be a non-empty string'), { status: 400 });
        }
        if (data.phone_number && !/^\d{10,15}$/.test(data.phone_number)) {
            throw Object.assign(new Error('Phone number must be between 10-15 digits'), { status: 400 });
        }
        if (data.email && !/^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$/.test(data.email)) {
            throw Object.assign(new Error('Invalid email format'), { status: 400 });
        }
    }

    static async findAllMembers() {
        const result = await query('SELECT * FROM members ORDER BY last_name, first_name');
        return result.rows;
    }

    static async findMemberById(id) {
        const result = await query('SELECT * FROM members WHERE id = $1', [id]);
        return result.rows[0];
    }

    static async createMember(memberData) {
        MemberService.validateMemberData(memberData);

        const { first_name, last_name, address, phone_number, email } = memberData;

        try {
            const result = await query(
                'INSERT INTO members (first_name, last_name, address, phone_number, email) VALUES ($1, $2, $3, $4, $5) RETURNING *',
                [first_name, last_name, address, phone_number, email]
            );
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') {
                if (error.constraint === 'members_phone_number_key') {
                    throw Object.assign(new Error('Phone number already exists'), { status: 400 });
                }
                if (error.constraint === 'members_email_key') {
                    throw Object.assign(new Error('Email already exists'), { status: 400 });
                }
            }
            throw error;
        }
    }

    static async updateMember(id, memberData) {
        MemberService.validateMemberData(memberData, true);

        const fields = [];
        const values = [];
        let paramIndex = 1;

        if (memberData.first_name !== undefined) {
            fields.push(`first_name = $${paramIndex++}`);
            values.push(memberData.first_name);
        }
        if (memberData.last_name !== undefined) {
            fields.push(`last_name = $${paramIndex++}`);
            values.push(memberData.last_name);
        }
        if (memberData.address !== undefined) {
            fields.push(`address = $${paramIndex++}`);
            values.push(memberData.address);
        }
        if (memberData.phone_number !== undefined) {
            fields.push(`phone_number = $${paramIndex++}`);
            values.push(memberData.phone_number);
        }
        if (memberData.email !== undefined) {
            fields.push(`email = $${paramIndex++}`);
            values.push(memberData.email);
        }

        if (fields.length === 0) {
            return MemberService.findMemberById(id); // No fields to update, return current member
        }

        values.push(id);
        try {
            const result = await query(
                `UPDATE members SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${paramIndex} RETURNING *`,
                values
            );
            return result.rows[0];
        } catch (error) {
            if (error.code === '23505') {
                if (error.constraint === 'members_phone_number_key') {
                    throw Object.assign(new Error('Phone number already exists'), { status: 400 });
                }
                if (error.constraint === 'members_email_key') {
                    throw Object.assign(new Error('Email already exists'), { status: 400 });
                }
            }
            throw error;
        }
    }

    static async deleteMember(id) {
        // Check if the member has any active loans
        const activeLoans = await query(
            "SELECT id FROM loans WHERE member_id = $1 AND (status = 'borrowed' OR status = 'overdue')",
            [id]
        );
        if (activeLoans.rowCount > 0) {
            throw Object.assign(new Error('Cannot delete member with active loans'), { status: 400 });
        }

        const result = await query('DELETE FROM members WHERE id = $1 RETURNING id', [id]);
        return result.rowCount > 0;
    }

    static async getMemberLoans(memberId) {
        const result = await query(
            `SELECT l.id, b.title as book_title, b.author as book_author, l.borrow_date, l.due_date, l.return_date, l.fine_amount, l.status
             FROM loans l JOIN books b ON l.book_id = b.id WHERE l.member_id = $1 ORDER BY l.borrow_date DESC`,
            [memberId]
        );
        return result.rows;
    }
}

module.exports = MemberService;