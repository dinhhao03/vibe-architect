const { query } = require('../db');

class LoanService {
    static validateLoanData(data, isBorrow = true) {
        if (isBorrow) {
            if (!data.book_id || !data.member_id || !data.due_date) {
                throw Object.assign(new Error('Book ID, Member ID, and Due Date are required to borrow a book'), { status: 400 });
            }
            if (isNaN(new Date(data.due_date).getTime())) {
                throw Object.assign(new Error('Invalid due_date format'), { status: 400 });
            }
            if (new Date(data.due_date) < new Date()) {
                throw Object.assign(new Error('Due date cannot be in the past'), { status: 400 });
            }
        }
        // Add more validation for other fields if they become editable via generic update
    }

    static async findAllLoans() {
        const result = await query(
            `SELECT l.id, b.title as book_title, m.first_name || ' ' || m.last_name as member_name, l.borrow_date, l.due_date, l.return_date, l.fine_amount, l.status
             FROM loans l JOIN books b ON l.book_id = b.id JOIN members m ON l.member_id = m.id ORDER BY l.borrow_date DESC`
        );
        return result.rows;
    }

    static async findLoanById(id) {
        const result = await query(
            `SELECT l.id, b.title as book_title, m.first_name || ' ' || m.last_name as member_name, l.borrow_date, l.due_date, l.return_date, l.fine_amount, l.status
             FROM loans l JOIN books b ON l.book_id = b.id JOIN members m ON l.member_id = m.id WHERE l.id = $1`,
            [id]
        );
        return result.rows[0];
    }

    static async borrowBook(loanData) {
        LoanService.validateLoanData(loanData, true);
        const { book_id, member_id, due_date } = loanData;

        // Start a transaction
        const client = await query('BEGIN');
        try {
            // 1. Check book availability
            const bookResult = await query('SELECT total_copies, available_copies FROM books WHERE id = $1 FOR UPDATE', [book_id]);
            if (bookResult.rowCount === 0) {
                throw Object.assign(new Error('Book not found'), { status: 404 });
            }
            const book = bookResult.rows[0];
            if (book.available_copies <= 0) {
                throw Object.assign(new Error('No copies of this book are available for borrowing'), { status: 400 });
            }

            // 2. Check member existence
            const memberResult = await query('SELECT id FROM members WHERE id = $1', [member_id]);
            if (memberResult.rowCount === 0) {
                throw Object.assign(new Error('Member not found'), { status: 404 });
            }

            // 3. Create loan record
            const loanInsertResult = await query(
                'INSERT INTO loans (book_id, member_id, due_date, status) VALUES ($1, $2, $3, $4) RETURNING *',
                [book_id, member_id, due_date, 'borrowed']
            );

            // 4. Decrease available copies of the book
            await query('UPDATE books SET available_copies = available_copies - 1, updated_at = CURRENT_TIMESTAMP WHERE id = $1', [book_id]);

            await query('COMMIT');
            return loanInsertResult.rows[0];
        } catch (error) {
            await query('ROLLBACK');
            throw error;
        }
    }

    static async returnBook(loanId) {
        const client = await query('BEGIN');
        try {
            // 1. Get loan details
            const loanResult = await query('SELECT * FROM loans WHERE id = $1 FOR UPDATE', [loanId]);
            if (loanResult.rowCount === 0) {
                throw Object.assign(new Error('Loan not found'), { status: 404 });
            }
            const loan = loanResult.rows[0];

            if (loan.status === 'returned') {
                throw Object.assign(new Error('Book already returned for this loan'), { status: 400 });
            }

            const returnDate = new Date();
            const dueDate = new Date(loan.due_date);
            let fineAmount = 0.00;
            const finePerDay = 0.50; // Example fine: 0.50 per day overdue

            if (returnDate > dueDate) {
                const diffTime = Math.abs(returnDate.getTime() - dueDate.getTime());
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                fineAmount = diffDays * finePerDay;
            }

            // 2. Update loan record
            const updatedLoanResult = await query(
                'UPDATE loans SET return_date = $1, fine_amount = $2, status = $3, updated_at = CURRENT_TIMESTAMP WHERE id = $4 RETURNING *',
                [returnDate, fineAmount, 'returned', loanId]
            );

            // 3. Increase available copies of the book
            await query('UPDATE books SET available_copies = available_copies + 1, updated_at = CURRENT_TIMESTAMP WHERE id = $1', [loan.book_id]);

            await query('COMMIT');
            return updatedLoanResult.rows[0];
        } catch (error) {
            await query('ROLLBACK');
            throw error;
        }
    }

    static async updateLoan(id, loanData) {
        // This method is for generic updates, returnBook handles specific return logic
        // Validation here should be for fields allowed to be updated outside return process
        // For example, extending due_date, changing status to 'lost' (requires specific logic).
        // For this project, only returnBook implements complex update logic.
        // If basic updates are needed (e.g., changing due date before return), add logic here.

        const fields = [];
        const values = [];
        let paramIndex = 1;

        if (loanData.due_date !== undefined) {
            if (isNaN(new Date(loanData.due_date).getTime())) {
                throw Object.assign(new Error('Invalid due_date format'), { status: 400 });
            }
            fields.push(`due_date = $${paramIndex++}`);
            values.push(loanData.due_date);
        }
        if (loanData.status !== undefined) {
            if (!['borrowed', 'returned', 'overdue', 'lost'].includes(loanData.status)) {
                throw Object.assign(new Error('Invalid loan status'), { status: 400 });
            }
            fields.push(`status = $${paramIndex++}`);
            values.push(loanData.status);
        }
        // Note: fine_amount and return_date are typically set by returnBook, not manual update.

        if (fields.length === 0) {
            return LoanService.findLoanById(id); // No fields to update, return current loan
        }

        values.push(id);
        const result = await query(
            `UPDATE loans SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE id = $${paramIndex} RETURNING *`,
            values
        );
        return result.rows[0];
    }
}

module.exports = LoanService;