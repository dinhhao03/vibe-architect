const express = require('express');
const MemberController = require('../controllers/memberController');

const router = express.Router();

router.get('/', MemberController.getAllMembers);
router.post('/', MemberController.createMember);
router.get('/:id', MemberController.getMemberById);
router.put('/:id', MemberController.updateMember);
router.delete('/:id', MemberController.deleteMember);
router.get('/:id/loans', MemberController.getMemberLoanHistory);

module.exports = router;