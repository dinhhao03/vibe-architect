const express = require('express');
const LoanController = require('../controllers/loanController');

const router = express.Router();

router.get('/', LoanController.getAllLoans);
router.post('/', LoanController.borrowBook); // US003
router.get('/:id', LoanController.getLoanById);
router.put('/:id/return', LoanController.returnBook); // US004
router.put('/:id', LoanController.updateLoan); // For generic updates, e.g., extending due date, not the return flow

module.exports = router;