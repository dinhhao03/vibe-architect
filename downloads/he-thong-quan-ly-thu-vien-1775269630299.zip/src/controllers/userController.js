const UserService = require('../services/userService');

class UserController {
    static async getAllUsers(req, res, next) {
        try {
            const users = await UserService.findAllUsers();
            res.status(200).json(users);
        } catch (e) {
            next(e);
        }
    }

    static async getUserById(req, res, next) {
        try {
            const { id } = req.params;
            const user = await UserService.findUserById(id);
            if (!user) {
                return res.status(404).json({ error: { message: 'User not found' } });
            }
            res.status(200).json(user);
        } catch (e) {
            next(e);
        }
    }

    static async createUser(req, res, next) {
        try {
            const userData = req.body;
            const newUser = await UserService.createUser(userData);
            res.status(201).json(newUser);
        } catch (e) {
            next(e);
        }
    }

    static async updateUser(req, res, next) {
        try {
            const { id } = req.params;
            const userData = req.body;
            const updatedUser = await UserService.updateUser(id, userData);
            if (!updatedUser) {
                return res.status(404).json({ error: { message: 'User not found' } });
            }
            res.status(200).json(updatedUser);
        } catch (e) {
            next(e);
        }
    }

    static async deleteUser(req, res, next) {
        try {
            const { id } = req.params;
            const success = await UserService.deleteUser(id);
            if (!success) {
                return res.status(404).json({ error: { message: 'User not found' } });
            }
            res.status(200).json({ message: 'User deleted successfully' });
        } catch (e) {
            next(e);
        }
    }
}

module.exports = UserController;