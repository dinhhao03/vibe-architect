const BookService = require('../services/bookService');

class BookController {
    static async getAllBooks(req, res, next) {
        try {
            const { title, author } = req.query;
            const books = await BookService.findAllBooks(title, author);
            res.status(200).json(books);
        } catch (e) {
            next(e);
        }
    }

    static async getBookById(req, res, next) {
        try {
            const { id } = req.params;
            const book = await BookService.findBookById(id);
            if (!book) {
                return res.status(404).json({ error: { message: 'Book not found' } });
            }
            res.status(200).json(book);
        } catch (e) {
            next(e);
        }
    }

    static async createBook(req, res, next) {
        try {
            const bookData = req.body;
            const newBook = await BookService.createBook(bookData);
            res.status(201).json(newBook);
        } catch (e) {
            next(e);
        }
    }

    static async updateBook(req, res, next) {
        try {
            const { id } = req.params;
            const bookData = req.body;
            const updatedBook = await BookService.updateBook(id, bookData);
            if (!updatedBook) {
                return res.status(404).json({ error: { message: 'Book not found' } });
            }
            res.status(200).json(updatedBook);
        } catch (e) {
            next(e);
        }
    }

    static async deleteBook(req, res, next) {
        try {
            const { id } = req.params;
            const success = await BookService.deleteBook(id);
            if (!success) {
                return res.status(404).json({ error: { message: 'Book not found or still has available copies (implies borrowed)' } });
            }
            res.status(200).json({ message: 'Book deleted successfully' });
        } catch (e) {
            next(e);
        }
    }
}

module.exports = BookController;