const LoanService = require('../services/loanService');

class LoanController {
    static async getAllLoans(req, res, next) {
        try {
            const loans = await LoanService.findAllLoans();
            res.status(200).json(loans);
        } catch (e) {
            next(e);
        }
    }

    static async getLoanById(req, res, next) {
        try {
            const { id } = req.params;
            const loan = await LoanService.findLoanById(id);
            if (!loan) {
                return res.status(404).json({ error: { message: 'Loan not found' } });
            }
            res.status(200).json(loan);
        } catch (e) {
            next(e);
        }
    }

    static async borrowBook(req, res, next) {
        try {
            const { book_id, member_id, due_date } = req.body;
            const newLoan = await LoanService.borrowBook({ book_id, member_id, due_date });
            res.status(201).json(newLoan);
        } catch (e) {
            next(e);
        }
    }

    static async returnBook(req, res, next) {
        try {
            const { id } = req.params; // loan_id
            const returnedLoan = await LoanService.returnBook(id);
            if (!returnedLoan) {
                return res.status(404).json({ error: { message: 'Loan not found or already returned' } });
            }
            res.status(200).json(returnedLoan);
        } catch (e) {
            next(e);
        }
    }

    // Method to potentially update a loan (e.g., extend due date) - if needed, not explicitly in AC
    static async updateLoan(req, res, next) {
        try {
            const { id } = req.params;
            const loanData = req.body;
            const updatedLoan = await LoanService.updateLoan(id, loanData);
            if (!updatedLoan) {
                return res.status(404).json({ error: { message: 'Loan not found' } });
            }
            res.status(200).json(updatedLoan);
        } catch (e) {
            next(e);
        }
    }
}

module.exports = LoanController;