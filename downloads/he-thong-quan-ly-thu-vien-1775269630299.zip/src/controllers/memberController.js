const MemberService = require('../services/memberService');

class MemberController {
    static async getAllMembers(req, res, next) {
        try {
            const members = await MemberService.findAllMembers();
            res.status(200).json(members);
        } catch (e) {
            next(e);
        }
    }

    static async getMemberById(req, res, next) {
        try {
            const { id } = req.params;
            const member = await MemberService.findMemberById(id);
            if (!member) {
                return res.status(404).json({ error: { message: 'Member not found' } });
            }
            res.status(200).json(member);
        } catch (e) {
            next(e);
        }
    }

    static async createMember(req, res, next) {
        try {
            const memberData = req.body;
            const newMember = await MemberService.createMember(memberData);
            res.status(201).json(newMember);
        } catch (e) {
            next(e);
        }
    }

    static async updateMember(req, res, next) {
        try {
            const { id } = req.params;
            const memberData = req.body;
            const updatedMember = await MemberService.updateMember(id, memberData);
            if (!updatedMember) {
                return res.status(404).json({ error: { message: 'Member not found' } });
            }
            res.status(200).json(updatedMember);
        } catch (e) {
            next(e);
        }
    }

    static async deleteMember(req, res, next) {
        try {
            const { id } = req.params;
            const success = await MemberService.deleteMember(id);
            if (!success) {
                return res.status(404).json({ error: { message: 'Member not found or has active loans' } });
            }
            res.status(200).json({ message: 'Member deleted successfully' });
        } catch (e) {
            next(e);
        }
    }

    static async getMemberLoanHistory(req, res, next) {
        try {
            const { id } = req.params;
            const loans = await MemberService.getMemberLoans(id);
            res.status(200).json(loans);
        } catch (e) {
            next(e);
        }
    }
}

module.exports = MemberController;