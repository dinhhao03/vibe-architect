# he-thong-quan-ly-thu-vien Backend

This is the backend for the Library Management System, built with Node.js, Express.js, and PostgreSQL.

## Project Overview

This system allows librarians to manage books, members, and track loan history. It automatically calculates fines for overdue books and provides a convenient book search function by title and author for members.

## Tech Stack

*   **Node.js**: JavaScript runtime environment
*   **Express.js**: Web application framework
*   **PostgreSQL**: Relational database
*   **`pg`**: PostgreSQL client for Node.js
*   **`dotenv`**: Loads environment variables from a `.env` file
*   **`cors`**: Express middleware for enabling Cross-Origin Resource Sharing
*   **`helmet`**: Express middleware for securing HTTP headers
*   **`express-rate-limit`**: Basic rate-limiting middleware

## Quick Start

1.  **Clone the repository:**
    ```bash
    git clone <repository-url>
    cd he-thong-quan-ly-thu-vien-backend
    ```

2.  **Install dependencies:**
    ```bash
    npm install
    ```

3.  **Set up your PostgreSQL database:**
    *   Ensure you have PostgreSQL installed and running.
    *   Create a new database (e.g., `library_db`).
    *   Run the provided SQL schema to create tables:

        ```sql
        CREATE TABLE users (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            username VARCHAR(50) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) NOT NULL DEFAULT 'librarian',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE members (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            address VARCHAR(255),
            phone_number VARCHAR(20) UNIQUE,
            email VARCHAR(100) UNIQUE,
            registration_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX idx_members_name ON members (first_name, last_name);
        CREATE INDEX idx_members_phone ON members (phone_number);
        CREATE INDEX idx_members_email ON members (email);

        CREATE TABLE books (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            title VARCHAR(255) NOT NULL,
            author VARCHAR(255) NOT NULL,
            isbn VARCHAR(13) NOT NULL UNIQUE,
            publication_year INT NOT NULL,
            genre VARCHAR(100),
            total_copies INT NOT NULL DEFAULT 1 CHECK (total_copies > 0),
            available_copies INT NOT NULL DEFAULT 1 CHECK (available_copies >= 0 AND available_copies <= total_copies),
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX idx_books_title ON books (title);
        CREATE INDEX idx_books_author ON books (author);
        CREATE INDEX idx_books_isbn ON books (isbn);


        CREATE TYPE loan_status AS ENUM ('borrowed', 'returned', 'overdue', 'lost');

        CREATE TABLE loans (
            id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
            book_id UUID NOT NULL,
            member_id UUID NOT NULL,
            borrow_date TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            due_date TIMESTAMP WITH TIME ZONE NOT NULL,
            return_date TIMESTAMP WITH TIME ZONE,
            fine_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00 CHECK (fine_amount >= 0),
            status loan_status NOT NULL DEFAULT 'borrowed',
            created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE RESTRICT,
            FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE RESTRICT
        );

        CREATE INDEX idx_loans_book_id ON loans (book_id);
        CREATE INDEX idx_loans_member_id ON loans (member_id);
        CREATE INDEX idx_loans_status ON loans (status);
        ```

4.  **Create a `.env` file** in the root directory with your database connection details:
    ```
    PORT=3000
    PGUSER=your_username
    PGHOST=localhost
    PGDATABASE=library_db
    PGPASSWORD=your_password
    PGPORT=5432
    ```

5.  **Start the server:**
    ```bash
    npm start
    ```
    The server will be running on `http://localhost:3000` (or your specified PORT).

## API Endpoints

All endpoints are prefixed with `/api`.

### Users

| Method | Path        | Description                       | Request Body                                       | Response (200/201)                                            |
| :----- | :---------- | :-------------------------------- | :------------------------------------------------- | :------------------------------------------------------------ |
| `POST`   | `/api/users` | Create a new user                 | `{ username, password_hash, role }`                | `User object`                                                 |
| `GET`    | `/api/users` | Get all users                     | `None`                                             | `Array of user objects`                                       |
| `GET`    | `/api/users/:id` | Get user by ID                    | `None`                                             | `User object`                                                 |
| `PUT`    | `/api/users/:id` | Update user by ID                 | `{ username?, password_hash?, role? }`             | `User object`                                                 |
| `DELETE` | `/api/users/:id` | Delete user by ID                 | `None`                                             | `{ message: "User deleted successfully" }`                    |

### Members

| Method | Path           | Description                         | Request Body                                                              | Response (200/201)                                              |
| :----- | :------------- | :---------------------------------- | :------------------------------------------------------------------------ | :-------------------------------------------------------------- |
| `POST`   | `/api/members`  | Create a new member (US002)         | `{ first_name, last_name, address?, phone_number?, email? }`              | `Member object`                                                 |
| `GET`    | `/api/members`  | Get all members                     | `None`                                                                    | `Array of member objects`                                       |
| `GET`    | `/api/members/:id` | Get member by ID                    | `None`                                                                    | `Member object`                                                 |
| `PUT`    | `/api/members/:id` | Update member by ID                 | `{ first_name?, last_name?, address?, phone_number?, email? }`            | `Member object`                                                 |
| `DELETE` | `/api/members/:id` | Delete member by ID                 | `None`                                                                    | `{ message: "Member deleted successfully" }`                  |
| `GET`    | `/api/members/:id/loans` | Get loan history for a member (US006) | `None`                                                                    | `Array of loan objects`                                         |

### Books

| Method | Path         | Description                           | Request Body                                                                                          | Response (200/201)                                              |
| :----- | :----------- | :------------------------------------ | :---------------------------------------------------------------------------------------------------- | :-------------------------------------------------------------- |
| `POST`   | `/api/books`  | Add a new book (US001)                | `{ title, author, isbn, publication_year, genre?, total_copies }`                                     | `Book object`                                                   |
| `GET`    | `/api/books`  | Get all books or search (US005)       | `None` (or query params `?title=keyword&author=keyword`)                                              | `Array of book objects`                                         |
| `GET`    | `/api/books/:id` | Get book by ID                        | `None`                                                                                                | `Book object`                                                   |
| `PUT`    | `/api/books/:id` | Update book by ID (US007)            | `{ title?, author?, isbn?, publication_year?, genre?, total_copies?, available_copies? }`            | `Book object`                                                   |
| `DELETE` | `/api/books/:id` | Delete book by ID (US007)             | `None`                                                                                                | `{ message: "Book deleted successfully" }`                    |

### Loans

| Method | Path          | Description                               | Request Body                                              | Response (200/201)                                           |
| :----- | :------------ | :---------------------------------------- | :-------------------------------------------------------- | :----------------------------------------------------------- |
| `POST`   | `/api/loans`   | Borrow a book (US003)                     | `{ book_id, member_id, due_date }`                        | `Loan object`                                                |
| `GET`    | `/api/loans`   | Get all loans                             | `None`                                                    | `Array of loan objects`                                      |
| `GET`    | `/api/loans/:id` | Get loan by ID                            | `None`                                                    | `Loan object`                                                |
| `PUT`    | `/api/loans/:id/return` | Return a book and calculate fine (US004)  | `None`                                                    | `Loan object` (with `return_date` and `fine_amount` updated)|

## Folder Structure

```
.
├── src/
│   ├── controllers/
│   │   ├── bookController.js
│   │   ├── loanController.js
│   │   ├── memberController.js
│   │   └── userController.js
│   ├── services/
│   │   ├── bookService.js
│   │   ├── loanService.js
│   │   ├── memberService.js
│   │   └── userService.js
│   ├── routes/
│   │   ├── bookRoutes.js
│   │   ├── loanRoutes.js
│   │   ├── memberRoutes.js
│   │   └── userRoutes.js
│   ├── app.js
│   ├── db.js
│   └── server.js
├── .env.example
├── package.json
├── package-lock.json
└── README.md
```
