CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE devices (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    user_id uuid NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    model VARCHAR(100),
    location VARCHAR(255),
    is_online BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_devices_user_id ON devices(user_id);

CREATE TABLE device_states (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    device_id uuid NOT NULL,
    state VARCHAR(100) NOT NULL,
    value TEXT,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);

CREATE INDEX idx_device_states_device_id_recorded_at ON device_states(device_id, recorded_at);

CREATE TABLE scenes (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    user_id uuid NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    is_enabled BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_scenes_user_id ON scenes(user_id);

CREATE TABLE scene_actions (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    scene_id uuid NOT NULL,
    device_id uuid NOT NULL,
    action_type VARCHAR(100) NOT NULL,
    action_value TEXT NOT NULL,
    FOREIGN KEY (scene_id) REFERENCES scenes(id) ON DELETE CASCADE,
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);

CREATE INDEX idx_scene_actions_scene_id ON scene_actions(scene_id);

CREATE TABLE scene_triggers (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    scene_id uuid NOT NULL,
    trigger_type VARCHAR(100) NOT NULL,
    trigger_condition TEXT NOT NULL,
    FOREIGN KEY (scene_id) REFERENCES scenes(id) ON DELETE CASCADE
);

CREATE INDEX idx_scene_triggers_scene_id ON scene_triggers(scene_id);

CREATE TABLE activity_logs (
    id uuid PRIMARY KEY DEFAULT uuid_ossp.uuid_generate_v4(),
    user_id uuid,
    activity_type VARCHAR(100) NOT NULL,
    target_type VARCHAR(100),
    target_id uuid,
    details TEXT,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_activity_logs_user_id_timestamp ON activity_logs(user_id, timestamp);
CREATE INDEX idx_activity_logs_activity_type_timestamp ON activity_logs(activity_type, timestamp);

-- Trigger to update 'updated_at' timestamp for users table
CREATE OR REPLACE FUNCTION update_updated_at_column() 
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW(); 
   RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at
BEFORE UPDATE ON users FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_devices_updated_at
BEFORE UPDATE ON devices FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_scenes_updated_at
BEFORE UPDATE ON scenes FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();
