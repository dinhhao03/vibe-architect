# Smart Home Backend

This project provides a backend for a Smart Home system, managing IoT devices, automated scenes, user accounts, and activity logs.

## Tech Stack

*   Node.js
*   Express.js
*   PostgreSQL (pg)

## Dependencies

*   express
*   cors
*   dotenv
*   pg
*   helmet
*   express-rate-limit

## Project Structure

```
smart-home-backend/
├── src/
│   ├── controllers/
│   │   ├── authController.js
│   │   ├── deviceController.js
│   │   ├── deviceStateController.js
│   │   ├── sceneActionController.js
│   │   ├── sceneController.js
│   │   ├── sceneTriggerController.js
│   │   └── userController.js
│   ├── services/
│   │   ├── authService.js
│   │   ├── deviceService.js
│   │   ├── deviceStateService.js
│   │   ├── sceneActionService.js
│   │   ├── sceneService.js
│   │   ├── sceneTriggerService.js
│   │   └── userService.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │   ├── deviceRoutes.js
│   │   ├── deviceStateRoutes.js
│   │   ├── sceneActionRoutes.js
│   │   ├── sceneRoutes.js
│   │   ├── sceneTriggerRoutes.js
│   │   └── userRoutes.js
│   ├── db.js
│   ├── app.js
│   └── server.js
├── .env
├── .gitignore
├── package.json
└── README.md
```

## API Endpoints

### Authentication

*   `POST /api/auth/register` - Register a new user.
*   `POST /api/auth/login` - Log in an existing user.
*   `POST /api/auth/logout` - Log out the current user.

### Users

*   `GET /api/users` - Get all users (Admin only).
*   `GET /api/users/:id` - Get a specific user (Admin only).
*   `PUT /api/users/:id` - Update a user (Admin only).
*   `DELETE /api/users/:id` - Delete a user (Admin only).
*   `PUT /api/users/:id/activate` - Activate a user (Admin only).
*   `PUT /api/users/:id/deactivate` - Deactivate a user (Admin only).

### Devices

*   `POST /api/devices` - Add a new device.
*   `GET /api/devices` - Get all devices for the logged-in user.
*   `GET /api/devices/:id` - Get a specific device.
*   `PUT /api/devices/:id` - Update a device.
*   `DELETE /api/devices/:id` - Delete a device.

### Device States

*   `POST /api/devices/:deviceId/states` - Record a new device state.
*   `GET /api/devices/:deviceId/states` - Get all states for a device.

### Scenes

*   `POST /api/scenes` - Create a new scene.
*   `GET /api/scenes` - Get all scenes for the logged-in user.
*   `GET /api/scenes/:id` - Get a specific scene.
*   `PUT /api/scenes/:id` - Update a scene.
*   `DELETE /api/scenes/:id` - Delete a scene.
*   `POST /api/scenes/:id/execute` - Manually execute a scene.

### Scene Actions

*   `POST /api/scenes/:sceneId/actions` - Add an action to a scene.
*   `GET /api/scenes/:sceneId/actions` - Get all actions for a scene.
*   `PUT /api/scene-actions/:id` - Update a scene action.
*   `DELETE /api/scene-actions/:id` - Delete a scene action.

### Scene Triggers

*   `POST /api/scenes/:sceneId/triggers` - Add a trigger to a scene.
*   `GET /api/scenes/:sceneId/triggers` - Get all triggers for a scene.
*   `PUT /api/scene-triggers/:id` - Update a scene trigger.
*   `DELETE /api/scene-triggers/:id` - Delete a scene trigger.

### Activity Logs

*   `GET /api/activity-logs` - Get activity logs (filtered by user, device, etc.).
*   `GET /api/admin/activity-logs` - Get all activity logs (Admin only).

## Quick Start

1.  **Clone the repository**:
    ```bash
    git clone <repository-url>
    cd smart-home-backend
    ```
2.  **Install dependencies**:
    ```bash
    npm install
    ```
3.  **Set up environment variables**:
    Create a `.env` file in the root directory and add your PostgreSQL connection details:
    ```
    DB_USER=your_db_user
    DB_HOST=your_db_host
    DB_DATABASE=your_db_name
    DB_PASSWORD=your_db_password
    DB_PORT=5432
    JWT_SECRET=your_jwt_secret
    PORT=3000
    ```
4.  **Run the application**:
    ```bash
    npm start
    ```
    The API will be running on `http://localhost:3000`.

**Note**: Ensure your PostgreSQL server is running and accessible.
