const sceneService = require('../services/sceneService');
const sceneActionService = require('../services/sceneActionService');
const sceneTriggerService = require('../services/sceneTriggerService');
const activityLogService = require('../services/activityLogService');
const deviceService = require('../services/deviceService'); // To execute actions

class SceneController {
  static async createScene(req, res, next) {
    try {
      const userId = req.user.id;
      const newScene = await sceneService.createScene(userId, req.body);
      res.status(201).json(newScene);
    } catch (error) {
      next(error);
    }
  }

  static async getAllScenes(req, res, next) {
    try {
      const userId = req.user.id;
      const scenes = await sceneService.getAllScenes(userId);
      res.status(200).json(scenes);
    } catch (error) {
      next(error);
    }
  }

  static async getSceneById(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const scene = await sceneService.getSceneById(id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }
      res.status(200).json(scene);
    } catch (error) {
      next(error);
    }
  }

  static async updateScene(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const updatedScene = await sceneService.updateScene(id, userId, req.body);
      if (!updatedScene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }
      res.status(200).json(updatedScene);
    } catch (error) {
      next(error);
    }
  }

  static async deleteScene(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const deletedCount = await sceneService.deleteScene(id, userId);
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }
      res.status(200).json({ message: 'Scene deleted successfully' });
    } catch (error) {
      next(error);
    }
  }

  static async executeScene(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      const scene = await sceneService.getSceneById(id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      if (!scene.is_enabled) {
        return res.status(400).json({ error: 'Scene is disabled' });
      }

      const actions = await sceneActionService.getSceneActions(id);
      const executedActionDetails = [];

      // Simulate action execution (in a real system, this would interact with device APIs)
      for (const action of actions) {
        try {
          // Dummy execution - in reality, this would be an async call to device service/API
          console.log(`Executing action for device ${action.device_id}: ${action.action_type} with value ${action.action_value}`);
          // Simulate interaction with device API / service
          // const deviceStatus = await deviceService.executeAction(action.device_id, action.action_type, action.action_value);
          executedActionDetails.push({
            deviceId: action.device_id,
            actionType: action.action_type,
            actionValue: action.action_value,
            status: 'simulated_success'
          });
        } catch (actionError) {
          console.error(`Failed to execute action for device ${action.device_id}:`, actionError);
          executedActionDetails.push({
            deviceId: action.device_id,
            actionType: action.action_type,
            actionValue: action.action_value,
            status: 'failed',
            error: actionError.message
          });
        }
      }

      // Log the scene execution
      await activityLogService.createLog(userId, 'SCENE_EXECUTION', 'scene', id, `Scene '${scene.name}' executed manually.`);

      res.status(200).json({
        message: `Scene '${scene.name}' execution initiated.`, 
        results: executedActionDetails
      });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = SceneController;