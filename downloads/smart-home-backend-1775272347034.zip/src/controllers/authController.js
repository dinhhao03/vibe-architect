const authService = require('../services/authService');

class AuthController {
  static async register(req, res, next) {
    try {
      const newUser = await authService.register(req.body);
      res.status(201).json(newUser);
    } catch (error) {
      next(error);
    }
  }

  static async login(req, res, next) {
    try {
      const token = await authService.login(req.body);
      res.status(200).json({ token });
    } catch (error) {
      next(error);
    }
  }

  static async logout(req, res, next) {
    try {
      // Typically, logout is client-side (e.g., removing token)
      // If server-side session invalidation is needed, implement here.
      // For JWT, this might involve a blacklist mechanism.
      res.status(200).json({ message: 'Logged out successfully' });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = AuthController;