const userService = require('../services/userService');
const activityLogService = require('../services/activityLogService');

class UserController {
  // Admin routes - requires is_admin check in service/middleware
  static async getAllUsers(req, res, next) {
    try {
      const users = await userService.getAllUsers();
      res.status(200).json(users);
    } catch (error) {
      next(error);
    }
  }

  static async getUserById(req, res, next) {
    try {
      const { id } = req.params;
      const user = await userService.getUserById(id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      // Don't return sensitive info like password hash
      const { password_hash, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  }

  static async updateUser(req, res, next) {
    try {
      const { id } = req.params;
      // Prevent admins from changing is_admin or is_active status via general update
      const { password_hash, is_admin, is_active, ...updateData } = req.body;
      const updatedUser = await userService.updateUser(id, updateData);
      if (!updatedUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      // Log the update activity
      await activityLogService.createLog(req.user.id, 'USER_UPDATE', 'user', id, 'User profile updated.');
      res.status(200).json(updatedUser);
    } catch (error) {
      next(error);
    }
  }

  static async deleteUser(req, res, next) {
    try {
      const { id } = req.params;
      const deletedCount = await userService.deleteUser(id);
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'User not found' });
      }
      await activityLogService.createLog(req.user.id, 'USER_DELETE', 'user', id, 'User deleted.');
      res.status(200).json({ message: 'User deleted successfully' });
    } catch (error) {
      next(error);
    }
  }

  static async activateUser(req, res, next) {
    try {
      const { id } = req.params;
      const updatedUser = await userService.activateUser(id);
      if (!updatedUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      await activityLogService.createLog(req.user.id, 'USER_ACTIVATE', 'user', id, 'User account activated.');
      res.status(200).json(updatedUser);
    } catch (error) {
      next(error);
    }
  }

  static async deactivateUser(req, res, next) {
    try {
      const { id } = req.params;
      const updatedUser = await userService.deactivateUser(id);
      if (!updatedUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      await activityLogService.createLog(req.user.id, 'USER_DEACTIVATE', 'user', id, 'User account deactivated.');
      res.status(200).json(updatedUser);
    } catch (error) {
      next(error);
    }
  }

  // Specific user info for the logged-in user (GET /api/users/me)
  static async getMe(req, res, next) {
    try {
      const userId = req.user.id;
      const user = await userService.getUserById(userId);
      if (!user) {
        // This should ideally not happen if auth middleware works correctly
        return res.status(401).json({ error: 'Authentication failed' });
      }
      const { password_hash, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = UserController;