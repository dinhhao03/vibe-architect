const sceneActionService = require('../services/sceneActionService');
const sceneService = require('../services/sceneService');
const deviceService = require('../services/deviceService');

class SceneActionController {
  static async addSceneAction(req, res, next) {
    try {
      const { sceneId } = req.params;
      const userId = req.user.id;

      // Verify scene ownership
      const scene = await sceneService.getSceneById(sceneId, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      // Verify device ownership for the action
      const { device_id } = req.body;
      const device = await deviceService.getDeviceById(device_id, userId);
      if (!device) {
        return res.status(404).json({ error: 'Device for action not found or unauthorized' });
      }

      const newAction = await sceneActionService.addSceneAction(sceneId, req.body);
      res.status(201).json(newAction);
    } catch (error) {
      next(error);
    }
  }

  static async getSceneActions(req, res, next) {
    try {
      const { sceneId } = req.params;
      const userId = req.user.id;

      // Verify scene ownership
      const scene = await sceneService.getSceneById(sceneId, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const actions = await sceneActionService.getSceneActions(sceneId);
      res.status(200).json(actions);
    } catch (error) {
      next(error);
    }
  }

  static async updateSceneAction(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      // Verify action belongs to a scene owned by the user
      const action = await sceneActionService.getSceneActionById(id);
      if (!action) {
        return res.status(404).json({ error: 'Scene action not found' });
      }
      const scene = await sceneService.getSceneById(action.scene_id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }
      
      // Optionally verify device ownership again if needed, though scene ownership check implies it

      const updatedAction = await sceneActionService.updateSceneAction(id, req.body);
      res.status(200).json(updatedAction);
    } catch (error) {
      next(error);
    }
  }

  static async deleteSceneAction(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      // Verify action belongs to a scene owned by the user
      const action = await sceneActionService.getSceneActionById(id);
      if (!action) {
        return res.status(404).json({ error: 'Scene action not found' });
      }
      const scene = await sceneService.getSceneById(action.scene_id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const deletedCount = await sceneActionService.deleteSceneAction(id);
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Scene action not found' });
      }
      res.status(200).json({ message: 'Scene action deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = SceneActionController;