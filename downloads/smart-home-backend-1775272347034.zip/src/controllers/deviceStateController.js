const deviceStateService = require('../services/deviceStateService');
const deviceService = require('../services/deviceService'); // To check device ownership

class DeviceStateController {
  static async recordDeviceState(req, res, next) {
    try {
      const { deviceId } = req.params;
      const userId = req.user.id; // Assuming user ID is available

      // Verify device ownership first
      const device = await deviceService.getDeviceById(deviceId, userId);
      if (!device) {
        return res.status(404).json({ error: 'Device not found or unauthorized' });
      }

      const newState = await deviceStateService.recordDeviceState(deviceId, req.body);
      res.status(201).json(newState);
    } catch (error) {
      next(error);
    }
  }

  static async getDeviceStates(req, res, next) {
    try {
      const { deviceId } = req.params;
      const userId = req.user.id;

      // Verify device ownership
      const device = await deviceService.getDeviceById(deviceId, userId);
      if (!device) {
        return res.status(404).json({ error: 'Device not found or unauthorized' });
      }

      const states = await deviceStateService.getDeviceStates(deviceId);
      res.status(200).json(states);
    } catch (error) {
      next(error);
    }
  }
}

module.exports = DeviceStateController;