const deviceService = require('../services/deviceService');

class DeviceController {
  static async createDevice(req, res, next) {
    try {
      const userId = req.user.id; // Assuming user ID is attached to request after auth
      const newDevice = await deviceService.createDevice(userId, req.body);
      res.status(201).json(newDevice);
    } catch (error) {
      next(error);
    }
  }

  static async getAllDevices(req, res, next) {
    try {
      const userId = req.user.id;
      const devices = await deviceService.getAllDevices(userId);
      res.status(200).json(devices);
    } catch (error) {
      next(error);
    }
  }

  static async getDeviceById(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const device = await deviceService.getDeviceById(id, userId);
      if (!device) {
        return res.status(404).json({ error: 'Device not found' });
      }
      res.status(200).json(device);
    } catch (error) {
      next(error);
    }
  }

  static async updateDevice(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const updatedDevice = await deviceService.updateDevice(id, userId, req.body);
      if (!updatedDevice) {
        return res.status(404).json({ error: 'Device not found or unauthorized' });
      }
      res.status(200).json(updatedDevice);
    } catch (error) {
      next(error);
    }
  }

  static async deleteDevice(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;
      const deletedCount = await deviceService.deleteDevice(id, userId);
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Device not found or unauthorized' });
      }
      res.status(200).json({ message: 'Device deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = DeviceController;