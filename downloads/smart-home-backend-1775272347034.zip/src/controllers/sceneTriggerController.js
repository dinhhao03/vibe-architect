const sceneTriggerService = require('../services/sceneTriggerService');
const sceneService = require('../services/sceneService');

class SceneTriggerController {
  static async addSceneTrigger(req, res, next) {
    try {
      const { sceneId } = req.params;
      const userId = req.user.id;

      // Verify scene ownership
      const scene = await sceneService.getSceneById(sceneId, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const newTrigger = await sceneTriggerService.addSceneTrigger(sceneId, req.body);
      res.status(201).json(newTrigger);
    } catch (error) {
      next(error);
    }
  }

  static async getSceneTriggers(req, res, next) {
    try {
      const { sceneId } = req.params;
      const userId = req.user.id;

      // Verify scene ownership
      const scene = await sceneService.getSceneById(sceneId, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const triggers = await sceneTriggerService.getSceneTriggers(sceneId);
      res.status(200).json(triggers);
    } catch (error) {
      next(error);
    }
  }

  static async updateSceneTrigger(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      // Verify trigger belongs to a scene owned by the user
      const trigger = await sceneTriggerService.getSceneTriggerById(id);
      if (!trigger) {
        return res.status(404).json({ error: 'Scene trigger not found' });
      }
      const scene = await sceneService.getSceneById(trigger.scene_id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const updatedTrigger = await sceneTriggerService.updateSceneTrigger(id, req.body);
      res.status(200).json(updatedTrigger);
    } catch (error) {
      next(error);
    }
  }

  static async deleteSceneTrigger(req, res, next) {
    try {
      const { id } = req.params;
      const userId = req.user.id;

      // Verify trigger belongs to a scene owned by the user
      const trigger = await sceneTriggerService.getSceneTriggerById(id);
      if (!trigger) {
        return res.status(404).json({ error: 'Scene trigger not found' });
      }
      const scene = await sceneService.getSceneById(trigger.scene_id, userId);
      if (!scene) {
        return res.status(404).json({ error: 'Scene not found or unauthorized' });
      }

      const deletedCount = await sceneTriggerService.deleteSceneTrigger(id);
      if (deletedCount === 0) {
        return res.status(404).json({ error: 'Scene trigger not found' });
      }
      res.status(200).json({ message: 'Scene trigger deleted successfully' });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = SceneTriggerController;