const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: parseInt(process.env.DB_PORT, 10),
});

const query = async (text, params) => {
  const start = Date.now();
  try {
    const res = await pool.query(text, params);
    const duration = Date.now() - start;
    console.log('Executed query', { text, duration, rows: res.rowCount });
    return res;
  } catch (err) {
    console.error('Error executing query', { text });
    throw err;
  }
};

const connectDb = async () => {
  try {
    await pool.connect();
    console.log('Successfully connected to PostgreSQL database');
  } catch (err) {
    console.error('Database connection error:', err);
    process.exit(1); 
  }
};

module.exports = {
  query,
  pool,
  connectDb
};