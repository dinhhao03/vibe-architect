const express = require('express');
const router = express.Router({ mergeParams: true }); // Merge params to access sceneId from URL
const sceneTriggerController = require('../controllers/sceneTriggerController');
const authenticate = require('../middleware/authenticate');

// Apply authentication middleware
router.use(authenticate);

// POST /api/scenes/:sceneId/triggers - Add a trigger to a scene
router.post('/triggers', sceneTriggerController.addSceneTrigger);

// GET /api/scenes/:sceneId/triggers - Get all triggers for a scene
router.get('/triggers', sceneTriggerController.getSceneTriggers);

// Note: Updating/Deleting triggers usually requires specific trigger IDs.
// So, we'll use the base /api/scene-triggers/:id route defined below.

module.exports = router;