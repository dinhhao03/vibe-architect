const express = require('express');
const router = express.Router();
const sceneController = require('../controllers/sceneController');
const sceneActionRoutes = require('./sceneActionRoutes'); // Nested routes for actions
const sceneTriggerRoutes = require('./sceneTriggerRoutes'); // Nested routes for triggers
const authenticate = require('../middleware/authenticate');
const authorizeAdmin = require('../middleware/authorizeAdmin');
const activityLogController = require('../controllers/activityLogController'); // For admin log viewing

// Apply authentication middleware to all scene-related routes
router.use(authenticate);

// GET /api/scenes - Get all scenes for the logged-in user
router.get('/', sceneController.getAllScenes);

// POST /api/scenes - Create a new scene
router.post('/', sceneController.createScene);

// GET /api/scenes/:id - Get a specific scene
router.get('/:id', sceneController.getSceneById);

// PUT /api/scenes/:id - Update a scene
router.put('/:id', sceneController.updateScene);

// DELETE /api/scenes/:id - Delete a scene
router.delete('/:id', sceneController.deleteScene);

// POST /api/scenes/:id/execute - Manually execute a scene
router.post('/:id/execute', sceneController.executeScene);

// Nested routes for Scene Actions
router.use('/:sceneId', sceneActionRoutes);

// Nested routes for Scene Triggers
router.use('/:sceneId', sceneTriggerRoutes);

// Admin routes for viewing all logs (if admin panel is integrated here)
// router.get('/admin/logs', authenticate, authorizeAdmin, activityLogController.getAllActivityLogs);

module.exports = router;