const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authenticate = require('../middleware/authenticate'); // Assuming you have an auth middleware

// POST /api/auth/register
router.post('/register', authController.register);

// POST /api/auth/login
router.post('/login', authController.login);

// POST /api/auth/logout - requires authentication
router.post('/logout', authenticate, authController.logout);

module.exports = router;