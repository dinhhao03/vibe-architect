const express = require('express');
const router = express.Router();
const deviceController = require('../controllers/deviceController');
const authenticate = require('../middleware/authenticate');
const authorizeAdmin = require('../middleware/authorizeAdmin'); // For admin-specific routes if any

// Apply authentication middleware to all routes in this file
router.use(authenticate);

// GET /api/devices - Get all devices for the logged-in user
router.get('/', deviceController.getAllDevices);

// POST /api/devices - Add a new device
router.post('/', deviceController.createDevice);

// GET /api/devices/:id - Get a specific device
router.get('/:id', deviceController.getDeviceById);

// PUT /api/devices/:id - Update a device
router.put('/:id', deviceController.updateDevice);

// DELETE /api/devices/:id - Delete a device
router.delete('/:id', deviceController.deleteDevice);

// Example Admin route (if needed)
// router.get('/admin/all', authenticate, authorizeAdmin, (req, res, next) => {
//   // Fetch all devices for all users - requires admin privileges
//   // This would typically call a service method like deviceService.getAllDevicesForAdmin()
//   res.status(501).json({ message: 'Admin route not yet implemented' });
// });

module.exports = router;