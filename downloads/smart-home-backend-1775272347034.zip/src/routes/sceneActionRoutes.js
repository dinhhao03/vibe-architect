const express = require('express');
const router = express.Router({ mergeParams: true }); // Merge params to access sceneId from URL
const sceneActionController = require('../controllers/sceneActionController');
const authenticate = require('../middleware/authenticate');

// Apply authentication middleware
router.use(authenticate);

// POST /api/scenes/:sceneId/actions - Add an action to a scene
router.post('/actions', sceneActionController.addSceneAction);

// GET /api/scenes/:sceneId/actions - Get all actions for a scene
router.get('/actions', sceneActionController.getSceneActions);

// Note: Updating/Deleting actions usually requires specific action IDs, not just sceneId.
// So, we'll use the base /api/scene-actions/:id route defined below.

module.exports = router;