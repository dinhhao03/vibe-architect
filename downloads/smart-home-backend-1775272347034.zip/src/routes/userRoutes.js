const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const authenticate = require('../middleware/authenticate');
const authorizeAdmin = require('../middleware/authorizeAdmin');

// Public route for registration and login handled by authRoutes

// Routes that require authentication
router.use(authenticate);

// GET /api/users/me - Get logged-in user's own profile
router.get('/me', userController.getMe);

// Routes that require admin privileges
router.use(authorizeAdmin);

// GET /api/users - Get all users (Admin only)
router.get('/', userController.getAllUsers);

// GET /api/users/:id - Get a specific user (Admin only)
router.get('/:id', userController.getUserById);

// PUT /api/users/:id - Update a user (Admin only - NOTE: General update, specific status changes below)
router.put('/:id', userController.updateUser);

// DELETE /api/users/:id - Delete a user (Admin only)
router.delete('/:id', userController.deleteUser);

// PUT /api/users/:id/activate - Activate a user (Admin only)
router.put('/:id/activate', userController.activateUser);

// PUT /api/users/:id/deactivate - Deactivate a user (Admin only)
router.put('/:id/deactivate', userController.deactivateUser);

// Example: Add routes for granting/revoking admin if needed
// router.put('/:id/grant-admin', userController.grantAdmin);
// router.put('/:id/revoke-admin', userController.revokeAdmin);

module.exports = router;