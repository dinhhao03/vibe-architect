const express = require('express');
const router = express.Router({ mergeParams: true }); // Merge params to access deviceId from URL
const deviceStateController = require('../controllers/deviceStateController');
const authenticate = require('../middleware/authenticate');

// Apply authentication middleware
router.use(authenticate);

// POST /api/devices/:deviceId/states - Record a new device state
router.post('/states', deviceStateController.recordDeviceState);

// GET /api/devices/:deviceId/states - Get all states for a device
router.get('/states', deviceStateController.getDeviceStates);

module.exports = router;