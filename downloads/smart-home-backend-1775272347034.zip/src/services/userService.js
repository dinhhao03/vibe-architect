const { query } = require('../db');

class UserService {
  static validateUpdate(data) {
    // Basic validation for fields that can be updated by user or admin
    if (data.email && !/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(data.email)) {
      throw Object.assign(new Error('Invalid email format.'), { status: 400 });
    }
    if (data.first_name && data.first_name.length > 100) {
      throw Object.assign(new Error('First name cannot exceed 100 characters.'), { status: 400 });
    }
    if (data.last_name && data.last_name.length > 100) {
      throw Object.assign(new Error('Last name cannot exceed 100 characters.'), { status: 400 });
    }
    // is_active and is_admin are handled by specific admin functions
  }

  static async getAllUsers() {
    // Admin only - selection of fields should exclude password_hash
    const result = await query('SELECT id, email, first_name, last_name, is_active, is_admin, created_at, updated_at FROM users ORDER BY created_at DESC');
    return result.rows;
  }

  static async getUserById(id) {
    // Should exclude password_hash
    const result = await query('SELECT id, email, first_name, last_name, is_active, is_admin, created_at, updated_at FROM users WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async getUserByEmail(email) {
    // Should include password_hash for login verification
    const result = await query('SELECT id, email, password_hash, first_name, last_name, is_active, is_admin FROM users WHERE email = $1', [email]);
    return result.rows[0];
  }

  static async updateUser(id, userData) {
    UserService.validateUpdate(userData);

    const existingUser = await UserService.getUserById(id); // Get user to check existence
    if (!existingUser) {
      return null;
    }

    const updates = [];
    const values = [];
    let i = 1;

    if (userData.email !== undefined) {
      // Check if the new email is already in use by another user
      if (userData.email !== existingUser.email) {
        const emailCheck = await UserService.getUserByEmail(userData.email);
        if (emailCheck) {
          throw Object.assign(new Error('Email is already in use by another account.'), { status: 409 });
        }
      }
      updates.push(`email = $${i++}`);
      values.push(userData.email);
    }
    if (userData.first_name !== undefined) {
      updates.push(`first_name = $${i++}`);
      values.push(userData.first_name);
    }
    if (userData.last_name !== undefined) {
      updates.push(`last_name = $${i++}`);
      values.push(userData.last_name);
    }

    if (updates.length === 0) {
      return existingUser; // No changes to apply
    }

    values.push(id);

    const queryText = `UPDATE users SET ${updates.join(', ')} WHERE id = $${i} RETURNING id, email, first_name, last_name, is_active, is_admin, created_at, updated_at`;
    const result = await query(queryText, values);
    return result.rows[0];
  }

  static async deleteUser(id) {
    // Deleting a user might have cascading effects or require cleanup (e.g., anonymizing logs)
    // For now, assume CASCADE or SET NULL on FKs handles related data.
    const result = await query('DELETE FROM users WHERE id = $1 RETURNING id', [id]);
    return result.rowCount;
  }

  static async activateUser(id) {
    const result = await query('UPDATE users SET is_active = TRUE WHERE id = $1 RETURNING id, email, first_name, last_name, is_active, is_admin, created_at, updated_at', [id]);
    return result.rows[0];
  }

  static async deactivateUser(id) {
    const result = await query('UPDATE users SET is_active = FALSE WHERE id = $1 RETURNING id, email, first_name, last_name, is_active, is_admin, created_at, updated_at', [id]);
    return result.rows[0];
  }

  static async grantAdmin(id) {
      const result = await query('UPDATE users SET is_admin = TRUE WHERE id = $1 RETURNING id, email, first_name, last_name, is_active, is_admin, created_at, updated_at', [id]);
      return result.rows[0];
  }

  static async revokeAdmin(id) {
      const result = await query('UPDATE users SET is_admin = FALSE WHERE id = $1 RETURNING id, email, first_name, last_name, is_active, is_admin, created_at, updated_at', [id]);
      return result.rows[0];
  }
}

module.exports = UserService;