const { query } = require('../db');

class ActivityLogService {
    static async createLog(userId, activityType, targetType, targetId, details) {
        if (!activityType) {
            throw Object.assign(new Error('Activity type is required for logging.'), { status: 400 });
        }
        if (activityType.length > 100) {
            throw Object.assign(new Error('Activity type cannot exceed 100 characters.'), { status: 400 });
        }
        if (targetType && targetType.length > 100) {
            throw Object.assign(new Error('Target type cannot exceed 100 characters.'), { status: 400 });
        }

        const result = await query(
            'INSERT INTO activity_logs (user_id, activity_type, target_type, target_id, details, timestamp) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [userId, activityType, targetType, targetId, details || '', new Date()]
        );
        return result.rows[0];
    }

    static async getLogs(userId, filters = {}) {
        let queryText = 'SELECT * FROM activity_logs WHERE 1=1';
        const values = [];
        let paramIndex = 1;

        // Filter by user if not admin, or if specific user logs are requested
        if (userId) {
             // For admins, we might want to fetch all logs or specific user logs.
             // If userId here refers to the logged-in user and they are NOT admin,
             // we only show their logs. If they ARE admin, this filter might be conditional.
             // For simplicity, let's assume userId is the one whose logs we want.
             // A separate route/logic might be needed for admin to see ALL logs.
             queryText += ` AND user_id = $${paramIndex++}`;
             values.push(userId);
        }

        // Apply additional filters if provided
        if (filters.activityType) {
            queryText += ` AND activity_type ILIKE $${paramIndex++}`;
            values.push(`%${filters.activityType}%`);
        }
        if (filters.targetType) {
            queryText += ` AND target_type ILIKE $${paramIndex++}`;
            values.push(`%${filters.targetType}%`);
        }
        if (filters.targetId) {
            queryText += ` AND target_id = $${paramIndex++}`;
            values.push(filters.targetId);
        }
        if (filters.startDate) {
            queryText += ` AND timestamp >= $${paramIndex++}`;
            values.push(filters.startDate);
        }
        if (filters.endDate) {
            queryText += ` AND timestamp <= $${paramIndex++}`;
            values.push(filters.endDate);
        }

        queryText += ' ORDER BY timestamp DESC';
        
        const result = await query(queryText, values);
        return result.rows;
    }

    // Admin specific route to get all logs
    static async getAllLogsForAdmin(filters = {}) {
        let queryText = 'SELECT al.*, u.email as user_email FROM activity_logs al LEFT JOIN users u ON al.user_id = u.id WHERE 1=1';
        const values = [];
        let paramIndex = 1;

        if (filters.userId) {
            queryText += ` AND al.user_id = $${paramIndex++}`;
            values.push(filters.userId);
        }
        if (filters.activityType) {
            queryText += ` AND al.activity_type ILIKE $${paramIndex++}`;
            values.push(`%${filters.activityType}%`);
        }
        if (filters.targetType) {
            queryText += ` AND al.target_type ILIKE $${paramIndex++}`;
            values.push(`%${filters.targetType}%`);
        }
        if (filters.targetId) {
            queryText += ` AND al.target_id = $${paramIndex++}`;
            values.push(filters.targetId);
        }
        if (filters.startDate) {
            queryText += ` AND al.timestamp >= $${paramIndex++}`;
            values.push(filters.startDate);
        }
        if (filters.endDate) {
            queryText += ` AND al.timestamp <= $${paramIndex++}`;
            values.push(filters.endDate);
        }

        queryText += ' ORDER BY al.timestamp DESC';

        const result = await query(queryText, values);
        return result.rows;
    }

     // Implement log deletion if needed, e.g., for cleanup
    // static async deleteOldLogs(cutoffDate) {
    //     const result = await query('DELETE FROM activity_logs WHERE timestamp < $1 RETURNING id', [cutoffDate]);
    //     return result.rowCount;
    // }
}

module.exports = ActivityLogService;