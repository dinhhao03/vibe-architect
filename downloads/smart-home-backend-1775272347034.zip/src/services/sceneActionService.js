const { query } = require('../db');

class SceneActionService {
  static validateAddUpdate(data) {
    if (!data.device_id || !data.action_type || !data.action_value) {
      throw Object.assign(new Error('Device ID, action type, and action value are required.'), { status: 400 });
    }
    if (data.action_type.length > 100) {
      throw Object.assign(new Error('Action type cannot exceed 100 characters.'), { status: 400 });
    }
    // action_value is TEXT, so no length validation needed here.
  }

  static async addSceneAction(sceneId, actionData) {
    SceneActionService.validateAddUpdate(actionData);
    const result = await query(
      'INSERT INTO scene_actions (scene_id, device_id, action_type, action_value) VALUES ($1, $2, $3, $4) RETURNING *',
      [sceneId, actionData.device_id, actionData.action_type, actionData.action_value]
    );
    return result.rows[0];
  }

  static async getSceneActions(sceneId) {
    const result = await query('SELECT * FROM scene_actions WHERE scene_id = $1 ORDER BY id', [sceneId]); // Order might not be critical unless sequence matters
    return result.rows;
  }

  static async getSceneActionById(id) {
    const result = await query('SELECT * FROM scene_actions WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async updateSceneAction(id, actionData) {
    SceneActionService.validateAddUpdate(actionData);
    const existingAction = await SceneActionService.getSceneActionById(id);
    if (!existingAction) {
      return null;
    }

    const result = await query(
      'UPDATE scene_actions SET device_id = $1, action_type = $2, action_value = $3 WHERE id = $4 RETURNING *',
      [actionData.device_id || existingAction.device_id, actionData.action_type || existingAction.action_type, actionData.action_value || existingAction.action_value, id]
    );
    return result.rows[0];
  }

  static async deleteSceneAction(id) {
    const result = await query('DELETE FROM scene_actions WHERE id = $1 RETURNING id', [id]);
    return result.rowCount;
  }
}

module.exports = SceneActionService;