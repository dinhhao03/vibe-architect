const { query } = require('../db');

class SceneService {
  static validateCreateUpdate(data, isUpdate = false) {
    if (!data.name) {
      throw Object.assign(new Error('Scene name is required.'), { status: 400 });
    }
    if (data.name.length > 255) {
      throw Object.assign(new Error('Scene name cannot exceed 255 characters.'), { status: 400 });
    }
    // Description and is_enabled are optional or have defaults
  }

  static async createScene(userId, sceneData) {
    SceneService.validateCreateUpdate(sceneData);
    const result = await query(
      'INSERT INTO scenes (user_id, name, description, is_enabled) VALUES ($1, $2, $3, $4) RETURNING *',
      [userId, sceneData.name, sceneData.description || '', sceneData.is_enabled === undefined ? true : sceneData.is_enabled]
    );
    return result.rows[0];
  }

  static async getAllScenes(userId) {
    const result = await query('SELECT * FROM scenes WHERE user_id = $1 ORDER BY created_at DESC', [userId]);
    return result.rows;
  }

  static async getSceneById(id, userId) {
    const result = await query('SELECT * FROM scenes WHERE id = $1 AND user_id = $2', [id, userId]);
    return result.rows[0];
  }
  
  static async getSceneByIdForAdmin(id) { // For admin or system use when user_id check is not needed
    const result = await query('SELECT * FROM scenes WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async updateScene(id, userId, sceneData) {
    SceneService.validateCreateUpdate(sceneData, true);
    const existingScene = await SceneService.getSceneById(id, userId);
    if (!existingScene) {
      return null;
    }

    const updates = [];
    const values = [];
    let i = 1;

    if (sceneData.name !== undefined) {
      updates.push(`name = $${i++}`);
      values.push(sceneData.name);
    }
    if (sceneData.description !== undefined) {
      updates.push(`description = $${i++}`);
      values.push(sceneData.description);
    }
    if (sceneData.is_enabled !== undefined) {
      updates.push(`is_enabled = $${i++}`);
      values.push(sceneData.is_enabled);
    }

    if (updates.length === 0) {
      return existingScene;
    }

    values.push(id);
    values.push(userId);

    const queryText = `UPDATE scenes SET ${updates.join(', ')} WHERE id = $${i} AND user_id = $${i+1} RETURNING *`;
    const result = await query(queryText, values);
    return result.rows[0];
  }

  static async deleteScene(id, userId) {
    const result = await query('DELETE FROM scenes WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    return result.rowCount;
  }
}

module.exports = SceneService;