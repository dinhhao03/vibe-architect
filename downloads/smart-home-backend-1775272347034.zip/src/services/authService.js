const { query } = require('../db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const userService = require('./userService'); // Reuse user fetching logic

class AuthService {
  static validateRegisterInput(data) {
    if (!data.email || !data.password || !data.first_name || !data.last_name) {
      throw Object.assign(new Error('Email, password, first name, and last name are required.'), { status: 400 });
    }
    if (!/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i.test(data.email)) {
      throw Object.assign(new Error('Invalid email format.'), { status: 400 });
    }
    if (data.password.length < 6) {
      throw Object.assign(new Error('Password must be at least 6 characters long.'), { status: 400 });
    }
  }

  static async register(userData) {
    AuthService.validateRegisterInput(userData);

    const existingUser = await userService.getUserByEmail(userData.email);
    if (existingUser) {
      throw Object.assign(new Error('Email already in use.'), { status: 409 }); // Conflict
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(userData.password, salt);

    const result = await query(
      'INSERT INTO users (email, password_hash, first_name, last_name) VALUES ($1, $2, $3, $4) RETURNING id, email, first_name, last_name, created_at, updated_at',
      [userData.email, passwordHash, userData.first_name, userData.last_name]
    );

    const newUser = result.rows[0];
    // Optionally create an activity log for registration
    await require('./activityLogService').createLog(newUser.id, 'USER_REGISTER', 'user', newUser.id, 'User registered successfully.');
    return newUser;
  }

  static validateLoginInput(data) {
    if (!data.email || !data.password) {
      throw Object.assign(new Error('Email and password are required for login.'), { status: 400 });
    }
  }

  static async login(credentials) {
    AuthService.validateLoginInput(credentials);

    const user = await userService.getUserByEmail(credentials.email);
    if (!user) {
      throw Object.assign(new Error('Invalid email or password.'), { status: 401 });
    }

    if (!user.is_active) {
        throw Object.assign(new Error('Your account is inactive. Please contact support.'), { status: 403 });
    }

    const isMatch = await bcrypt.compare(credentials.password, user.password_hash);
    if (!isMatch) {
      throw Object.assign(new Error('Invalid email or password.'), { status: 401 });
    }

    const payload = {
      id: user.id,
      email: user.email,
      is_admin: user.is_admin
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: '1h' // Token expires in 1 hour
    });

    // Optionally create an activity log for login
    await require('./activityLogService').createLog(user.id, 'USER_LOGIN', 'user', user.id, 'User logged in.');

    return token;
  }
}

module.exports = AuthService;