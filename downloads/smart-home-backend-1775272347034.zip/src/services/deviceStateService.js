const { query } = require('../db');

class DeviceStateService {
  static validateRecordState(data) {
    if (!data.state) {
      throw Object.assign(new Error('State is required.'), { status: 400 });
    }
    if (data.state.length > 100) {
      throw Object.assign(new Error('State cannot exceed 100 characters.'), { status: 400 });
    }
    // Value can be anything, so no strict validation unless specific types are required
  }

  static async recordDeviceState(deviceId, stateData) {
    DeviceStateService.validateRecordState(stateData);
    const result = await query(
      'INSERT INTO device_states (device_id, state, value, recorded_at) VALUES ($1, $2, $3, $4) RETURNING *',
      [deviceId, stateData.state, stateData.value, stateData.recorded_at || new Date()]
    );
    return result.rows[0];
  }

  static async getDeviceStates(deviceId) {
    const result = await query('SELECT * FROM device_states WHERE device_id = $1 ORDER BY recorded_at DESC', [deviceId]);
    return result.rows;
  }
}

module.exports = DeviceStateService;