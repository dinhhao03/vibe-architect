const { query } = require('../db');

class SceneTriggerService {
  static validateAddUpdate(data) {
    if (!data.trigger_type || !data.trigger_condition) {
      throw Object.assign(new Error('Trigger type and trigger condition are required.'), { status: 400 });
    }
    if (data.trigger_type.length > 100) {
      throw Object.assign(new Error('Trigger type cannot exceed 100 characters.'), { status: 400 });
    }
    // trigger_condition is TEXT, so no length validation needed here.
  }

  static async addSceneTrigger(sceneId, triggerData) {
    SceneTriggerService.validateAddUpdate(triggerData);
    const result = await query(
      'INSERT INTO scene_triggers (scene_id, trigger_type, trigger_condition) VALUES ($1, $2, $3) RETURNING *',
      [sceneId, triggerData.trigger_type, triggerData.trigger_condition]
    );
    return result.rows[0];
  }

  static async getSceneTriggers(sceneId) {
    const result = await query('SELECT * FROM scene_triggers WHERE scene_id = $1 ORDER BY id', [sceneId]);
    return result.rows;
  }

  static async getSceneTriggerById(id) {
    const result = await query('SELECT * FROM scene_triggers WHERE id = $1', [id]);
    return result.rows[0];
  }

  static async updateSceneTrigger(id, triggerData) {
    SceneTriggerService.validateAddUpdate(triggerData);
    const existingTrigger = await SceneTriggerService.getSceneTriggerById(id);
    if (!existingTrigger) {
      return null;
    }

    const result = await query(
      'UPDATE scene_triggers SET trigger_type = $1, trigger_condition = $2 WHERE id = $3 RETURNING *',
      [triggerData.trigger_type || existingTrigger.trigger_type, triggerData.trigger_condition || existingTrigger.trigger_condition, id]
    );
    return result.rows[0];
  }

  static async deleteSceneTrigger(id) {
    const result = await query('DELETE FROM scene_triggers WHERE id = $1 RETURNING id', [id]);
    return result.rowCount;
  }
}

module.exports = SceneTriggerService;