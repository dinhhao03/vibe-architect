const { query } = require('../db');

class DeviceService {
  static validateCreateUpdate(data, isUpdate = false) {
    if (!data.name || !data.type) {
      throw Object.assign(new Error('Device name and type are required.'), { status: 400 });
    }
    if (data.name.length > 255) {
      throw Object.assign(new Error('Device name cannot exceed 255 characters.'), { status: 400 });
    }
    if (data.type.length > 100) {
      throw Object.assign(new Error('Device type cannot exceed 100 characters.'), { status: 400 });
    }
    if (data.model && data.model.length > 100) {
      throw Object.assign(new Error('Device model cannot exceed 100 characters.'), { status: 400 });
    }
    if (data.location && data.location.length > 255) {
      throw Object.assign(new Error('Device location cannot exceed 255 characters.'), { status: 400 });
    }
    // If updating, allow partial updates, but still validate provided fields
  }

  static async createDevice(userId, deviceData) {
    DeviceService.validateCreateUpdate(deviceData);
    const result = await query(
      'INSERT INTO devices (user_id, name, type, model, location, is_online) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [userId, deviceData.name, deviceData.type, deviceData.model, deviceData.location, deviceData.is_online || false]
    );
    return result.rows[0];
  }

  static async getAllDevices(userId) {
    const result = await query('SELECT * FROM devices WHERE user_id = $1 ORDER BY created_at DESC', [userId]);
    return result.rows;
  }

  static async getDeviceById(id, userId) {
    const result = await query('SELECT * FROM devices WHERE id = $1 AND user_id = $2', [id, userId]);
    return result.rows[0];
  }

  static async updateDevice(id, userId, deviceData) {
    DeviceService.validateCreateUpdate(deviceData, true);
    // Check if device exists and belongs to the user first
    const existingDevice = await DeviceService.getDeviceById(id, userId);
    if (!existingDevice) {
      return null; // Indicate not found or unauthorized
    }

    const updates = [];
    const values = [];
    let i = 1;

    if (deviceData.name !== undefined) {
      updates.push(`name = $${i++}`);
      values.push(deviceData.name);
    }
    if (deviceData.type !== undefined) {
      updates.push(`type = $${i++}`);
      values.push(deviceData.type);
    }
    if (deviceData.model !== undefined) {
      updates.push(`model = $${i++}`);
      values.push(deviceData.model);
    }
    if (deviceData.location !== undefined) {
      updates.push(`location = $${i++}`);
      values.push(deviceData.location);
    }
    if (deviceData.is_online !== undefined) {
      updates.push(`is_online = $${i++}`);
      values.push(deviceData.is_online);
    }
    
    if (updates.length === 0) {
      // No fields to update, return the existing device
      return existingDevice;
    }

    values.push(id); // For the WHERE clause
    values.push(userId); // For the WHERE clause

    const queryText = `UPDATE devices SET ${updates.join(', ')} WHERE id = $${i} AND user_id = $${i+1} RETURNING *`;
    const result = await query(queryText, values);
    return result.rows[0];
  }

  static async deleteDevice(id, userId) {
    const result = await query('DELETE FROM devices WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    return result.rowCount;
  }
}

module.exports = DeviceService;