const http = require('http');
const app = require('./app');
const { connectDb } = require('./db');

const PORT = process.env.PORT || 3000;

// Connect to the database first
connectDb().then(() => {
  const server = http.createServer(app);

  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Graceful Shutdown
  const shutdown = async (signal) => {
    console.log(`
Received signal: ${signal}. Shutting down gracefully...`);
    server.close(async () => {
      console.log('HTTP server closed.');
      // Close the database connection pool
      try {
        await require('./db').pool.end();
        console.log('Database connection pool closed.');
        process.exit(0);
      } catch (err) {
        console.error('Error closing database pool:', err);
        process.exit(1);
      }
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

}).catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});