# Tai Lieu Yeu Cau Phan Mem (SRS)
## smart-home-backend

## 1. Tong Quan Du An
Dự án backend Smart Home quản lý các thiết bị IoT, cho phép người dùng tạo các Scene tự động kích hoạt dựa trên lịch trình hoặc các điều kiện nhất định. Hệ thống cũng ghi lại lịch sử hoạt động của các thiết bị và Scene để người dùng có thể theo dõi.

## 2. User Stories
### US001 - Quản lý thiết bị IoT

**Story:** Là người dùng thông thường, tôi muốn có thể thêm, xem, sửa đổi và xóa các thiết bị IoT của mình để quản lý nhà thông minh dễ dàng.

**Acceptance Criteria:**
  - Người dùng có thể thêm thiết bị mới bằng cách cung cấp tên, loại thiết bị và thông tin kết nối.
  - Người dùng có thể xem danh sách tất cả các thiết bị đã thêm, bao gồm trạng thái hoạt động (bật/tắt, giá trị cảm biến).
  - Người dùng có thể sửa đổi thông tin của thiết bị đã có.
  - Người dùng có thể xóa thiết bị khỏi danh sách quản lý.

### US002 - Tạo Scene tự động

**Story:** Là người dùng thông thường, tôi muốn tạo các Scene tự động hóa để điều khiển nhiều thiết bị cùng lúc theo điều kiện hoặc lịch trình.

**Acceptance Criteria:**
  - Người dùng có thể tạo một Scene mới, đặt tên cho Scene và chọn các hành động cho từng thiết bị (ví dụ: bật đèn, tắt quạt).
  - Người dùng có thể thiết lập điều kiện kích hoạt Scene, ví dụ: theo giờ cụ thể trong ngày, hoặc khi một cảm biến đạt ngưỡng nhất định.
  - Người dùng có thể kích hoạt Scene thủ công.

### US003 - Xem lịch sử hoạt động

**Story:** Là người dùng thông thường, tôi muốn xem lịch sử hoạt động của các thiết bị và Scene đã được kích hoạt để biết được những gì đã xảy ra trong nhà.

**Acceptance Criteria:**
  - Hệ thống ghi lại log mỗi khi một thiết bị được bật/tắt hoặc thay đổi trạng thái.
  - Hệ thống ghi lại log mỗi khi một Scene được kích hoạt (thủ công hoặc tự động).
  - Người dùng có thể xem danh sách các log hoạt động, bao gồm thời gian, loại sự kiện, và thiết bị/Scene liên quan.

### US004 - Quản lý tài khoản người dùng

**Story:** Là người dùng, tôi muốn có thể đăng ký, đăng nhập và đăng xuất khỏi hệ thống để truy cập các tính năng của Smart Home.

**Acceptance Criteria:**
  - Người dùng có thể tạo tài khoản mới bằng email và mật khẩu.
  - Người dùng có thể đăng nhập bằng email và mật khẩu đã đăng ký.
  - Người dùng có thể đăng xuất khỏi hệ thống.

### US005 - Cài đặt thiết bị ban đầu

**Story:** Là người dùng mới, tôi muốn có thể kết nối thiết bị IoT của mình với hệ thống để bắt đầu sử dụng.

**Acceptance Criteria:**
  - Hệ thống cung cấp hướng dẫn để người dùng tìm và kết nối thiết bị IoT mới.
  - Sau khi kết nối thành công, thiết bị sẽ hiển thị trong danh sách thiết bị của người dùng.

### US006 - Cấu hình Scene nâng cao

**Story:** Là người dùng nâng cao, tôi muốn có thể thiết lập các điều kiện phức tạp hơn cho Scene để tự động hóa nhà thông minh theo nhu cầu chi tiết.

**Acceptance Criteria:**
  - Người dùng có thể tạo Scene với nhiều điều kiện kích hoạt kết hợp (AND/OR).
  - Người dùng có thể thiết lập hành động theo trình tự cho các thiết bị trong một Scene.

### US007 - Xem và quản lý log hệ thống (Admin)

**Story:** Là quản trị viên, tôi muốn xem toàn bộ log hoạt động của hệ thống để giám sát và xử lý sự cố.

**Acceptance Criteria:**
  - Quản trị viên có thể truy cập vào một giao diện quản lý log riêng.
  - Quản trị viên có thể lọc log theo thời gian, loại sự kiện, người dùng hoặc thiết bị.
  - Quản trị viên có thể xóa các log cũ để tiết kiệm dung lượng lưu trữ (tùy chọn cấu hình).

### US008 - Quản lý người dùng (Admin)

**Story:** Là quản trị viên, tôi muốn xem danh sách tất cả người dùng và có thể khóa/mở khóa tài khoản của họ để quản lý người dùng hệ thống.

**Acceptance Criteria:**
  - Quản trị viên có thể xem danh sách tất cả tài khoản người dùng đã đăng ký.
  - Quản trị viên có thể xem chi tiết thông tin của từng người dùng.
  - Quản trị viên có thể khóa hoặc mở khóa tài khoản của người dùng.